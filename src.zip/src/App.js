import logo from './logo.svg';
import './App.css';
import BoardGame from './BoardGame';

function App() {
  return (
    <div className="App">
    <BoardGame/>
    </div>
  );
}

export default App;
